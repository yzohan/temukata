# TemuKata Penguin Mascot

Paket berisi artwork penguin tanpa alis (ekspresi lebih netral dan imut), berdasarkan referensi terakhir.

## Isi folder
- `temukata-penguin.png`: PNG master dengan latar biru muda seperti referensi.
- `temukata-penguin-transparent.png`: PNG transparan untuk ditaruh di atas komponen website.
- `temukata-penguin.svg`: SVG mandiri yang menampilkan PNG transparan yang sama persis. Ini menjaga tampilan tetap identik; artwork di dalamnya masih raster, bukan path vektor yang bisa diedit per bagian.
- `temukata-penguin.css`: animasi float dan hop saat hover.
- `demo.html`: contoh penggunaan.

## Cara pakai
Simpan file SVG dan CSS di folder yang sama, lalu:

```html
<link rel="stylesheet" href="temukata-penguin.css">

<div class="temukata-mascot">
  <img src="temukata-penguin.svg" alt="Maskot penguin TemuKata">
</div>
```

CSS memberi animasi melayang dan lompatan ketika di-hover. Karena artwork dijaga sebagai satu gambar agar persis sama dengan PNG, mata/sayap belum dipisah menjadi layer untuk animasi kedip atau gerak independen.
